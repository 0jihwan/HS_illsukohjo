using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    public Transform cameraTransform;
    public CharacterController characterController;
    [SerializeField]
    private float movespeed = 5f;
    [SerializeField]
    private float jumpspeed = 10f;
    [SerializeField]
    private float gravity = -20f;
    [SerializeField]
    private float yVelocity = 0;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Cursor.visible = true;
        Cursor.lockState = CursorLockMode.Confined;
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        Vector3 moveDirection = new Vector3(h, 0 ,v);
        moveDirection = cameraTransform.TransformDirection(moveDirection);
        moveDirection *= movespeed;

        if (characterController.isGrounded)
        {
            yVelocity = 0;
            if (Input.GetKeyUp(KeyCode.Space))
            {
                yVelocity = jumpspeed;
            }
        }
        yVelocity += (gravity * Time.deltaTime);
        moveDirection.y = yVelocity;
        characterController.Move(moveDirection* Time.deltaTime);

        if(Input.GetKey("escape"))
            Application.Quit();

    }
}

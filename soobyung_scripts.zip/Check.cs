using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Check : MonoBehaviour
{
    
    public static int key = 0;
    public GameObject pass;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void check(InputField f)
    {
        if (f.text == "1234")
        {
            key = 1;

            print("���� ���ȴ�");
            pass.SetActive(false);
        }
        else print("�ƹ��ϵ� ���°� ����");
                pass.SetActive(false) ;
       
    }
}
